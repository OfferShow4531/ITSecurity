﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ITSecurity
{
    /// <summary>
    /// Логика взаимодействия для ResultPage.xaml
    /// </summary>
    public partial class ResultPage : Window
    {
       
        public string time = DateTime.Now.ToString();
        public List<AskingList> Asking { get; set; } = Data.GetAll(DataSource.CountOverall());
        public ResultPage()
        {
            InitializeComponent();
            SendButton.Visibility = Visibility.Hidden;

        }

        public void SendButton_Click(object sender, RoutedEventArgs e)
        {      
            label_Name.Content = "Общий результат: " + DataSource.CountOverall() + " из " + DataSource.result/2;
            PrintDialog pd = new PrintDialog();
            if(pd.ShowDialog() == true)
            {
                IDocumentPaginatorSource idp = FlowDoc;
                pd.PrintDocument(idp.DocumentPaginator, "Flow Document");
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            Client.Content = FIO.Text;
            date_year.Text = time;
            SendButton.Visibility = Visibility.Visible;
        }

    }
}
