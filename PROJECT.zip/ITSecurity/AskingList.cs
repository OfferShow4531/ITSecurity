﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ITSecurity
{
    public class AskingList
    {
        public int id { get; set; }
        public string content { get; set; }
        public int security_level { get; set; }
        public string content_information { get; set; }
    }
}
