﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ITSecurity
{
    public class Data
    {

        public static List<AskingList> GetAll(double counter)
        {

            var list = new List<AskingList>();
            using (var ctx = new DataContext())
            {
                foreach (var i in ctx.Asks)
                {
                    if (counter < 5)
                    {

                        list.Add(i);
                        list.RemoveAll(c => c.security_level > 5);
                    }
                    if (counter < 9 && counter > 4)
                    {
                        list.Add(i);
                        list.RemoveAll(c => c.security_level < 5);
                        //list.RemoveAll(id => i.security_level < 4);
                        //list.RemoveAll(content => i.security_level < 4);
                        //list.RemoveAll(content_information => i.security_level < 4);
                        list.RemoveAll(c => c.security_level > 9);
                        //list.RemoveAll(id => i.security_level > 9);
                        //list.RemoveAll(content => i.security_level > 9);
                        //list.RemoveAll(content_information => i.security_level > 9);

                    }
                    if (counter < 13 && counter > 8)
                    {
                        list.Add(i);
                        list.RemoveAll(c => c.security_level < 9);
                        //list.RemoveAll(id => i.security_level < 8);
                        //list.RemoveAll(content => i.security_level < 8);
                        //list.RemoveAll(content_information => i.security_level < 8);
                        list.RemoveAll(c => c.security_level > 17);
                        //list.RemoveAll(id => i.security_level > 13);
                        //list.RemoveAll(content => i.security_level > 13);
                        //list.RemoveAll(content_information => i.security_level > 13);
                    }
                    if (counter > 12)
                    {
                        list.Add(i);
                        list.RemoveAll(c => c.security_level < 17);
                        //list.RemoveAll(id => i.security_level < 12);
                        //list.RemoveAll(content => i.security_level < 12);
                        //list.RemoveAll(content_information => i.security_level < 12);
                    }
                }
            }
            return list;


        }
        public static List<AskingList> GetResult()
        {

            var list = new List<AskingList>();
            using (var ctx = new DataContext())
            {
                foreach (var i in ctx.Asks)
                {
                    list.Add(i);
                }
            }
            return list;
        }
    }
}
