﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace ITSecurity
{
    static class DataSource
    {
        public static int res = 0;
        public static int sec_result = 0;
        public static int result = 0;
        public static double overall = 0;
       
        public static int[] counter = new int[7];
        //public static int[] counter_sec = new int[7];

        public static readonly string[] changedForm = { "Да", "Нет", "Сомневаюсь в ответе", "Возможно" };
        public static readonly string[] percentChange = { "25%", "50%", "75%", "100%" };
        public static readonly string[] verificationForm = { "Низкая", "Средняя", "Выше среднего", "Высокая" };

        public static readonly string[] sec_changedForm = { "Отсутствует полностью", "Частично имеется", "Возможно", "Имеется" };
        public static readonly string[] sec_percentChange = { "Слабо защищены", "Защищены, но не полностью", "Имеют среднюю защиту", "Полностью защищены" };
        public static readonly string[] sec_verificationForm = { "Меня устраивает моя система", "Возможно хотел", "Скорее всего", "Да, хочу" };
        public static readonly string[] versionForm = { "Приемлимая (От 100 до 150 тыс.)", "Защищенная (От 250 - 350 тыс.)", "Высокая (От 450 до 550 тыс.)", "Профессиональная (от 600 тыс и выше)" };
        public static readonly string[] askForm = { "Не знаком", "Где-то слышал", "Имею представление", "Да, знаком" };
        
        public static void checkAllSum()
        {
            foreach (var item in counter)
            {
                if (counter[item] < 3)
                {
                    counter[item] = 3;
                }
                result += counter[item];

            }

            MessageBox.Show(result.ToString());
        }

        public static double CountOverall()
        {
            return Math.Round(overall / 2);
        }
    }
}
