﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ITSecurity
{
    /// <summary>
    /// Логика взаимодействия для MainScreen.xaml
    /// </summary>
    public partial class MainScreen : Window
    {
        public MainScreen()
        {
            InitializeComponent();
            new ImageBrush(new BitmapImage(new Uri(BaseUriHelper.GetBaseUri(this), "main_screen.jpg")));
        }


        private void start_test(object sender, RoutedEventArgs e)
        {
            MainWindow NewWindow = new MainWindow();
            NewWindow.Show();
            this.Close();
        }

        private void help_operation(object sender, RoutedEventArgs e)
        {
            Help_Desk HelpWindow = new Help_Desk();
            HelpWindow.Show();
            this.Close();

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            DataContextPage dataBaseResult = new DataContextPage();
            dataBaseResult.Show();
            this.Close();

        }
    }
}
