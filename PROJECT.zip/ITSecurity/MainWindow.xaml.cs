﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ITSecurity
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public string text { get; set; }
        public MainWindow()
        {
            
            InitializeComponent();
            populateWPFComboBox();
           



        }
        public int res = DataSource.res;
        public int result = DataSource.result;
        public int[] counter = DataSource.counter;
        private readonly string[] changedForm = DataSource.changedForm;
        private readonly string[] percentChange = DataSource.percentChange;
        private readonly string[] verificationForm = DataSource.verificationForm;
        
        
        
        
        string output = string.Empty;
       
        private void populateWPFComboBox()
        {
            panel_1.ItemsSource = changedForm;
            
            panel_2.ItemsSource = percentChange;
            
            panel_3.ItemsSource = changedForm;
           
            panel_4.ItemsSource = changedForm;
            
            panel_5.ItemsSource = verificationForm;
          
            panel_6.ItemsSource = changedForm;
            
            panel_7.ItemsSource = changedForm;
           
        }
        public void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
            switch (panel_1.SelectedIndex)
            {
                case 0:
                    counter[0] = 3;
                       
                    break;
                case 1:
                    counter[0] = 0;

                    break;
                case 2:
                    counter[0] = 1;
                    
                    break;
                case 3:
                    counter[0] = 2;
                   
                    break;

                default:
                    break;
            }
            
        }


        public void ComboBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {
            
            switch (panel_2.SelectedIndex)
            {
                case 0:
                    counter[1] = 0;
                   

                    break;
                case 1:
                    counter[1] = 1;
                   
                    break;
                case 2:
                    counter[1] = 2;
                   
                    break;
                case 3:
                    counter[1] = 3;
                   
                    break;

                default:
                    break;
            }
            
        }


        public void ComboBox_SelectionChanged_2(object sender, SelectionChangedEventArgs e)
        {
            
            switch (panel_3.SelectedIndex)
            {
                case 0:
                    counter[2] = 3;
                    

                    break;
                case 1:
                    counter[2] = 0;
                   
                    break;
                case 2:
                    counter[2] = 1;
                   

                    break;
                case 3:
                    counter[2] = 2;
                    
                    break;

                default:
                    break;
            }
            
        }

        public void ComboBox_SelectionChanged_3(object sender, SelectionChangedEventArgs e)
        {
            
            switch (panel_4.SelectedIndex)
            {
                case 0:
                    counter[3] = 3;
                   

                    break;
                case 1:
                    counter[3] = 0;
                    
                    break;
                case 2:
                    counter[3] = 1;
                    
                    break;
                case 3:
                    counter[3] = 2;
                   

                    break;

                default:
                    break;
            }
            
        }

        public void ComboBox_SelectionChanged_4(object sender, SelectionChangedEventArgs e)
        {
            
            switch (panel_5.SelectedIndex)
            {
                case 0:
                    counter[4] = 0;
                    

                    break;
                case 1:
                    counter[4] = 1;
                   

                    break;
                case 2:
                    counter[4] = 2;
                    

                    break;
                case 3:
                    counter[4] = 3;
                   

                    break;

                default:
                    break;
            }
            
        }

        public void ComboBox_SelectionChanged_5(object sender, SelectionChangedEventArgs e)
        {
           
            switch (panel_6.SelectedIndex)
            {
                case 0:
                    counter[5] = 3;
                   

                    break;
                case 1:
                    counter[5] = 0;
                    

                    break;
                case 2:
                    counter[5] = 1;
                    

                    break;
                case 3:
                    counter[5] = 2;
                   

                    break;

                default:
                    break;
            }
            
        }

        public void ComboBox_SelectionChanged_6(object sender, SelectionChangedEventArgs e)
        {
           
            switch (panel_7.SelectedIndex)
            {
                case 0:
                    counter[6] = 3;
                   

                    break;
                case 1:
                    counter[6] = 0;
                    
                    break;
                case 2:
                    counter[6] = 1;
                    
                   
                    break;
                case 3:
                    counter[6] = 2;
                    
               
                    break;

                default:
                    break;
            }
            button_check.Visibility = Visibility.Visible;
        }

        public void button_check_Click(object sender, RoutedEventArgs e)
        {
            
            controlWork();
            
        }

        public int AllSum()
        {
            for (int i = 0; i < counter.Length; i++)
            {
                result += counter[i];
            }
            return result;
        }
        private void controlWork()
        {
            
            if (counter.Length >= 6)
            {
                if(MessageBox.Show("Хотите продолжить опрос или изменить выбранные?", "Переход на следующие вопросы", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.No)
                {
                    MessageBox.Show("Хорошо");
                    Array.Clear(counter, 0, counter.Length);
                    result = 0;
                    panel_1.SelectedIndex = -1;
                    panel_2.SelectedIndex = -1;
                    panel_3.SelectedIndex = -1;
                    panel_4.SelectedIndex = -1;
                    panel_5.SelectedIndex = -1;
                    panel_6.SelectedIndex = -1;
                    panel_7.SelectedIndex = -1;
                    button_check.Visibility = Visibility.Hidden;
                }
                else
                {
                    result = counter.Sum();
                    DataSource.overall += result;
                    Array.Clear(counter, 0, counter.Length);
                    MessageBox.Show(result.ToString());
                    DataSource.checkAllSum();
                    MainWindow2 NewWindow = new MainWindow2();
                    NewWindow.Show();
                    //Array.Clear(counter, 0, counter.Length);
                    this.Close();
                }
            }
        }

    }
}
