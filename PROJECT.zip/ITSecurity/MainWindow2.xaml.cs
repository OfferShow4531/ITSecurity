﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ITSecurity
{
    /// <summary>
    /// Логика взаимодействия для MainWindow2.xaml
    /// </summary>
    public partial class MainWindow2 : Window
    {
      
        public MainWindow2()
        {
            InitializeComponent();
            populateWPFComboBox();
        }

        private readonly string[] changedForm = DataSource.sec_changedForm;
        private readonly string[] percentChange = DataSource.sec_percentChange;
        private readonly string[] verificationForm = DataSource.sec_verificationForm;
        private readonly string[] versionForm = DataSource.verificationForm;
        private readonly string[] askForm = DataSource.askForm;

       
        public int result_real = DataSource.sec_result;
        public int result_all = DataSource.res;
        public int[] counter_2 = DataSource.counter;
        string output = string.Empty;


        private void populateWPFComboBox()
        {
            viewbox_secondpanel_1.ItemsSource = changedForm;

            viewbox_secondpanel_2.ItemsSource = percentChange;

            viewbox_secondpanel_3.ItemsSource = changedForm;

            viewbox_secondpanel_4.ItemsSource = verificationForm;

            viewbox_secondpanel_5.ItemsSource = verificationForm;

            viewbox_secondpanel_6.ItemsSource = versionForm;

            viewbox_secondpanel_7.ItemsSource = askForm;

        }
        private void SecondBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
           
            switch (viewbox_secondpanel_1.SelectedIndex)
            {
                case 0:
                    counter_2[0] = 0;


                    break;
                case 1:
                    counter_2[0] = 1;



                    break;
                case 2:
                    counter_2[0] = 2;



                    break;
                case 3:
                    counter_2[0] = 3;

                    break;

                default:
                    break;
            }
        }

        private void SecondBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {
            
            switch (viewbox_secondpanel_2.SelectedIndex)
            {
                case 0:
                    counter_2[1] = 0;


                    break;
                case 1:
                    counter_2[1] = 1;



                    break;
                case 2:
                    counter_2[1] = 2;



                    break;
                case 3:
                    counter_2[1] = 3;

                    break;

                default:
                    break;
            }
        }

        private void SecondBox_SelectionChanged_2(object sender, SelectionChangedEventArgs e)
        {
           
            switch (viewbox_secondpanel_3.SelectedIndex)
            {
                case 0:
                    counter_2[2] = 0;


                    break;
                case 1:
                    counter_2[2] = 1;



                    break;
                case 2:
                    counter_2[2] = 2;



                    break;
                case 3:
                    counter_2[2] = 3;

                    break;

                default:
                    break;
            }
        }

        private void SecondBox_SelectionChanged_3(object sender, SelectionChangedEventArgs e)
        {
            
            switch (viewbox_secondpanel_4.SelectedIndex)
            {
                case 0:
                    counter_2[3] = 0;


                    break;
                case 1:
                    counter_2[3] = 1;



                    break;
                case 2:
                    counter_2[3] = 2;



                    break;
                case 3:
                    counter_2[3] = 3;

                    break;

                default:
                    break;
            }
        }

        private void SecondBox_SelectionChanged_4(object sender, SelectionChangedEventArgs e)
        {
            
            switch (viewbox_secondpanel_5.SelectedIndex)
            {
                case 0:
                    counter_2[4] = 0;


                    break;
                case 1:
                    counter_2[4] = 1;



                    break;
                case 2:
                    counter_2[4] = 2;



                    break;
                case 3:
                    counter_2[4] = 3;

                    break;

                default:
                    break;
            }
        }

        private void SecondBox_SelectionChanged_5(object sender, SelectionChangedEventArgs e)
        {
            
            switch (viewbox_secondpanel_6.SelectedIndex)
            {
                case 0:
                    counter_2[5] = 0;


                    break;
                case 1:
                    counter_2[5] = 1;



                    break;
                case 2:
                    counter_2[5] = 2;



                    break;
                case 3:
                    counter_2[5] = 3;

                    break;

                default:
                    break;
            }
        }

        private void SecondBox_SelectionChanged_6(object sender, SelectionChangedEventArgs e)
        {
           
            switch (viewbox_secondpanel_7.SelectedIndex)
            {
                case 0:
                    counter_2[6] = 0;


                    break;
                case 1:
                    counter_2[6] = 1;



                    break;
                case 2:
                    counter_2[6] = 2;
                   


                    break;
                case 3:
                    counter_2[6] = 3;

                    break;

                default:
                    break;
            }
            button_check.Visibility = Visibility.Visible;

        }
        public void button_check_Click(object sender, RoutedEventArgs e)
        {
            
            controlWork();
          
        }
        private void controlWork()
        {
            
            if (counter_2.Length >= 6)
            {
                if (MessageBox.Show("Хотите продолжить опрос или изменить выбранные?", "Переход на следующие вопросы", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.No)
                {
                    MessageBox.Show("Хорошо");
                    Array.Clear(counter_2, 0, counter_2.Length);
                    button_check.Visibility = Visibility.Hidden;
                    result_all = 0;
                    viewbox_secondpanel_1.SelectedIndex = -1;
                    viewbox_secondpanel_2.SelectedIndex = -1;
                    viewbox_secondpanel_3.SelectedIndex = -1;
                    viewbox_secondpanel_4.SelectedIndex = -1;
                    viewbox_secondpanel_5.SelectedIndex = -1;
                    viewbox_secondpanel_6.SelectedIndex = -1;
                    viewbox_secondpanel_7.SelectedIndex = -1;
                }
                else
                {
                    result_all = counter_2.Sum();
                    DataSource.overall += result_all;
                    MessageBox.Show(result_all.ToString());
                    DataSource.checkAllSum();
                    ResultPage NewWindow = new ResultPage();
                    NewWindow.Show();
                    this.Close();
                }
            }
        }
        

       
    }
}
